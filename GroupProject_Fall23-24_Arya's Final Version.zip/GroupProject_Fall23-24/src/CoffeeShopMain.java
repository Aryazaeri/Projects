
public class CoffeeShopMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CoffeeShopSys.readFromFile();
		//CoffeeShopSys.findItem(1758);
		System.out.println(CoffeeShopSys.display());
		//System.out.println(CoffeeShopSys.addCustomer());
		
	}

}
