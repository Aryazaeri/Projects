import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class CoffeeShopSys {
	private static ArrayList<CoffeeShop> al = new ArrayList<CoffeeShop>();
	
	public static void readFromFile() {
		try {
			Scanner inp = new Scanner(new File("coffeeShop.txt"));
			CoffeeShop item ;
			double price;
			int q,orderid,portion;
			String size,name,type;
			while(inp.hasNext()) {
				type = inp.next();
				switch(type) {
				case "Food":
					price = inp.nextDouble();
					q = inp.nextInt();
					portion = inp.nextInt();
					orderid = inp.nextInt();
					name = inp.nextLine();
					item = new Food(price,q,orderid,portion);
						if(orderid<200)
							item.discount(0.10);
					al.add(item);
					break;
				case "Beverage":
					price = inp.nextDouble();
					q = inp.nextInt();
					size = inp.next();
					orderid = inp.nextInt();
					name = inp.nextLine();
					item = new Beverage(price,q,orderid,size);
					al.add(item);
					break;
				}
			}
			inp.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void addItem(String deliveryType, String nameSurname) {
		
		CoffeeShop temp = null;
		
		String ch= "";
		do {
			temp.getInput();
			al.add(temp);
		}while(ch.equalsIgnoreCase("no"));
		
		
		
		
//		for (CoffeeShop cs : al) {
//			if (cs.findOrderId(id)) {
//				foundCoffeeShop = cs;
//				break;
//			}
//		}
//		
//		if (foundCoffeeShop != null) {
//			customer = new Customer(deliveryType,nameSurname);
//			foundCoffeeShop.setCustomer(customer);
//		}
		
	}

	public static String addCustomer() {
		int i;
		String res = "";
		Customer temp = new Customer();
		for (i=0;i< al.size();i++) {
			temp.getInput();
			res += temp.toString();
		}
		
		return res;
	}
	
	public static void deleteItem(int id) {
		int i;
		for(i=0;i<al.size();i++) {
			if(al.get(i).getOrderId() == id)
				al.remove(i);
		}
	}

	public static void findItem(int id) {
		int i;
		String res = "";
		for(i=0;i<al.size();i++) {
			if(al.get(i).getOrderId() == id)
				res +=al.get(i).toString();
		}
		System.out.println("Searched Item\n"+res);
	}
	
public static String getCoffeeShopList(String type) {
		
		String result = "";
		CoffeeShop coffeeShop;
		
		for (int i = 0; i < al.size(); i++) {
			coffeeShop = al.get(i);
			
			if (type.equalsIgnoreCase("m") && coffeeShop instanceof Food) {
				result += ((Food)coffeeShop).toString() + "\n";
			} else if (type.equalsIgnoreCase("s") && coffeeShop instanceof Beverage) {
				result += ((Beverage)coffeeShop).toString() + "\n";
			} else if (type.equalsIgnoreCase("a")) {
				result += coffeeShop.toString() + "\n";
			}
		}
		
		return result;
	}

	public static String display() {
		String res = "";
		for (int i=0;i<al.size();i++) {
			res += al.get(i).toString()+"\n";
		}
		
		return res;
	}

	public static void writeToFile() {
		try {
			PrintWriter pw = new PrintWriter(new File("finalReceipt.txt"));
			for (int i = 0 ; i<al.size();i++) {
				pw.print(al.get(i).toString());
				
			}
			pw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
