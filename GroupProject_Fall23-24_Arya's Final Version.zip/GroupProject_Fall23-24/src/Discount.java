
public interface Discount {
	public void discount(int per);
}
