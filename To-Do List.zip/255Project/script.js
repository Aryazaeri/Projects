
$(document).ready(function () {
  // Function to get lists from local storage
  function getLists() {
      return JSON.parse(localStorage.getItem('lists') || '[]');
  }

  // Function to save lists to local storage
  function saveLists(lists) {
      localStorage.setItem('lists', JSON.stringify(lists));
  }

  // Function to add a list to the sidebar
  function addListToSidebar(list) {
      $('#lists').append('<li style="border:.5px solid black; border-style:initial;" class="list-item" data-id="' + list.id + '">' + list.name + ' (' + list.tasks.length + ') <button class="delete-list">Delete</button></li>', '</br>');
  } 

  // Function to update the task count for a list
  function updateListTaskCount(listId) {
      var lists = getLists();
      var list = lists.find(l => l.id === listId);
      if (!list) return;

      var taskCount = list.tasks.length;
      $('.list-item[data-id="' + listId + '"]').html(list.name + ' (' + taskCount + ') <button class="delete-list">Delete</button>');
  }

  // Function to display tasks for a specific list
  function displayTasks(listId) {
      var lists = getLists();
      var list = lists.find(l => l.id === listId);
      if (!list) return;

      $('#task-title h2').text(list.name);
      var tasksList = $('#tasks');
      tasksList.empty();

      list.tasks.forEach(function(task) {
          var taskItem = $('<li style="background-color:white; border:2px solid  #3399ff; border-radius:10px; padding:20px;" class="task-item" data-id="' + task.id + '">' +
              '<input type="checkbox" class="task-checkbox" ' + (task.completed ? 'checked' : '') + '>' +
              '<span class="task-name">' + task.name + '</span>' +
              '<button class="delete-task">Delete</button>' +
              '</li>');

          taskItem.find('.task-checkbox').change(function() {
              var taskId = $(this).parent().data('id');
              toggleTaskCompletion(listId, taskId);
          });

          taskItem.find('.delete-task').click(function() {
              var taskId = $(this).parent().data('id');
              deleteTask(listId, taskId);
          });

          tasksList.append(taskItem);
      });
  }

  // Function to create a new list
  function createNewList(listName) {
      var lists = getLists();
      var newList = {
          id: new Date().getTime(),
          name: listName,
          tasks: []
      };
      lists.push(newList);
      saveLists(lists);
      addListToSidebar(newList);
  }

  // Function to delete a list
  function deleteList(listId) {
      var lists = getLists();
      var updatedLists = lists.filter(l => l.id !== listId);
      saveLists(updatedLists);
      $('.list-item[data-id="' + listId + '"]').remove();
      $('#task-title h2').text('');
      $('#tasks').empty();
  }

  // Function to delete a task
  function deleteTask(listId, taskId) {
      var lists = getLists();
      var list = lists.find(l => l.id === listId);
      if (!list) return;

      list.tasks = list.tasks.filter(task => task.id !== taskId);
      saveLists(lists);
      displayTasks(listId);
      updateListTaskCount(listId);
  }

  // Function to toggle task completion
  function toggleTaskCompletion(listId, taskId) {
      var lists = getLists();
      var list = lists.find(l => l.id === listId);
      if (!list) return;

      var task = list.tasks.find(task => task.id === taskId);
      if (!task) return;

      task.completed = !task.completed;
      saveLists(lists);
      updateListTaskCount(listId);
  }

  // Function to create a new task in the current list
  function createNewTask(listId, taskName) {
      var lists = getLists();
      var list = lists.find(l => l.id === listId);
      if (!list) return;

      var newTask = {
          id: new Date().getTime(),
          name: taskName,
          completed: false
      };
      list.tasks.push(newTask);
      saveLists(lists);
      displayTasks(listId);
      updateListTaskCount(listId);
  }

  // Click event listener for the "Create New Task" button
  $('#create-task').click(function() {
      var taskName = $('#new-task-name').val().trim();
      if (!taskName) {
          alert("Task name can't be empty");
          return;
      }

      var listId = $('.list-item.active').data('id');
      createNewTask(listId, taskName);
      $('#new-task-name').val('');
  });

  // Click event listener for the "Delete Checked Tasks" button
  $('#delete-checked-tasks').click(function() {
      var listId = $('.list-item.active').data('id');
      var lists = getLists();
      var list = lists.find(l => l.id === listId);
      if (!list) return;

      list.tasks = list.tasks.filter(task => !task.completed);
      saveLists(lists);
      displayTasks(listId);
      updateListTaskCount(listId);
  });

  // Rest of your existing code...

  // Load lists on initial page load
  var lists = getLists();
  lists.forEach(function(list) {
      addListToSidebar(list);
  });

  // Click event listener for the "Create New List" button
  $('#new-list-btn').click(function() {
      $('#new-list-dialog').fadeIn();
  });

  // Click event listener for creating a new list
  $('#create-list').click(function() {
      var listName = $('#new-list-name').val().trim();
      if (!listName) {
          alert("List name can't be empty");
          return;
      }

      createNewList(listName);
      $('#new-list-name').val('');
      $('#new-list-dialog').fadeOut();
  });

  // Click event listener for canceling the new list creation
  $('#new-list-dialog .modal-close').click(function() {
      $('#new-list-name').val('');
      $('#new-list-dialog').fadeOut();
  });

  // Click event listener for clicking on a list in the sidebar
  $('#lists').on('click', '.list-item', function() {
      var listId = $(this).data('id');
      displayTasks(listId);
  });

  // Click event listener for deleting a list
  $('#lists').on('click', '.delete-list', function() {
      var listId = $(this).parent().data('id');
      deleteList(listId);
      displayProjectMembers();
  });

  // Click event listener for selecting a list in the sidebar
  $('#lists').on('click', '.list-item', function() {
    $('#main-content').removeClass('members-page-active'); // Add this line to ensure the class is removed
    $('#lists .list-item').removeClass('active');
    $(this).addClass('active');
    displayTasks($(this).data('id'));
  });


  // Load the first list's tasks on initial page load if available
  var firstList = $('#lists .list-item').first();
  if (firstList.length > 0) {
      var listId = firstList.data('id');
      displayTasks(listId);
      firstList.addClass('active');
  }

  function displayProjectMembers() {
    $('#main-content').addClass('members-page-active'); // Add this line to hide the "Add Task" section
    $('#task-title h2').text('\u2606 Project Members');
    $('#tasks').empty();

    // Add your project member display here.

    $('#tasks').append('<img style="width:95px; height:95px;"src="arya.jpg" alt="Profile Image" class="profile-img"><span style="font-size:15px;" class="email"><span style="font-weight:bold;">Hamid Zaeri</span> <br><br> Section-03 <br><br> 22101062</span>');
    $('#tasks').append('<li><br></li>');
    $('#tasks').append('<img style="width:95px; height:95px;"src="yekta.jpg" alt="Profile Image" class="profile-img"><span style="font-size:15px;" class="email"><span style="font-weight:bold;">Yekta Arda Öz</span><br><br> Section-02 <br><br> 22002177</span>');
    $('#tasks').append('<li><br></li>');
    $('#tasks').append('<img style="width:95px; height:95px;"src="efe.jpg" alt="Profile Image" class="profile-img"><span style="font-size:15px;" class="email"><span style="font-weight:bold;">Efe Sinanoğlu</span><br><br> Section-03 <br><br> 22002056</span>');
    $('#tasks').append('<li><br></li>');
    $('#tasks').append('<img style="width:95px; height:95px;"src="eren.jpg" alt="Profile Image" class="profile-img"><span style="font-size:15px;" class="email"><span style="font-weight:bold;">Eren Tarık Öksüzoğlu</span><br><br> Section-03 <br><br>22103430</span>');
    $('#tasks').append('<li><br></li>');
}

// Function to toggle between displaying lists and project members
function toggleListsOrMembers() {
    var listsContainer = $('#lists-container');
    var tasksDisplay = $('#task-display');
    
    if ($('#lists li').length === 0) {
        displayProjectMembers();
    } else {
        listsContainer.show();
        tasksDisplay.show();
    }
}

displayProjectMembers();
// Click event listener for the "Show Project Members" button
$('#show-members-button').click(function() {
    toggleListsOrMembers();
});



});
